#!/bin/sh
cd /tmp/maftmp
/usr/bin/unzip $1 -d $2
