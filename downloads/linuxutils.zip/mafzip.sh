#!/bin/sh
cd /tmp/maftmp
/usr/bin/zip -r $1 $2
